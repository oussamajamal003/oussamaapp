const Home = () => {
  return (
    <div className="text-white">
      <h1 className="text-2xl font-bold">Home Page</h1>
    </div>
  );
};

export default Home;
